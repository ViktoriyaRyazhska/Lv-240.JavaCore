package main;

import person.Person;

public class Main {

public static void main(String[] args) {
Person person1 = new Person();
person1.setNameAndBirthYear("Anna",1991);

Person person2 = new Person();
person2.setNameAndBirthYear("Taras",1987);

Person person3 = new Person();
person3.setName("Olga");
person3.setBirthYear(1980);

Person person4 = new Person();
person4.setName("Tanya");
person4.setBirthYear(1995);

Person person5 = new Person();
person5.setName("Stas");
person5.setBirthYear(2000);

int age1=person1.calculateAge();
person1.output();
System.out.println("Person1 is "+age1+" years old");
int age2=person2.calculateAge();
person2.output();
System.out.println("Person3 is "+age2+" years old");
int age3=person3.calculateAge();
person3.output();
System.out.println("Person4 is "+age3+" years old");
int age4=person4.calculateAge();
person4.output();
System.out.println("Person5 is "+age4+" years old");
int age5=person5.calculateAge();
person5.output();
System.out.println("Person6 is "+age5+" years old");
}
}
