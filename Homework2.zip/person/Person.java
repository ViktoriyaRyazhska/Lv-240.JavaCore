package person;

public class Person {
	private String name;
	private int birthYear;

public int calculateAge(){
	int age=2017-birthYear;
	return age;
}
public void output() {
	System.out.println(name+" was born in "+birthYear);
}
public void setNameAndBirthYear(String name, int birthYear){
	this.name=name;
	this.birthYear=birthYear;
}
public void setName(String name) {
	this.name=name;
}
public String getName() {
	return name;
}
public void setBirthYear(int birthYear) {
	this.birthYear=birthYear;
}
public int getBirthYear() {
	return birthYear;
}
public void changeName(String userName) {
this.name = userName;
}
}
